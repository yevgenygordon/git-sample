My awesome work progress!

Some changes